# 1.0.5-develop (2024-02-22)

## ✨ New features
- [#86cu5nh5n](https://app.clickup.com/t/86cu5nh5n) 
Food Fraudulent Transaction Detection

## 🐛 Fixes
- NA

## Improvements
- NA

## ⚙️ Deployment Instructions
### Pre deployment steps
- NA

### Post deployment steps
- NA

## Testing Scope QA Instructions
- NA

## Known bugs
- NA

---
# 1.0.4-develop (2023-09-22)

## ✨ New features
- [#85zu0n4re](https://app.clickup.com/t/85zu0n4re) 
Store top selling foods for each restaurant

## 🐛 Fixes
- NA

## Improvements
- NA

## ⚙️ Deployment Instructions
### Pre deployment steps
- NA

### Post deployment steps
- NA

## Testing Scope QA Instructions
- NA

## Known bugs
- NA

---
# 1.0.3-develop (2023-08-31)

## ✨ New features
- NA

## 🐛 Fixes
- NA

## Improvements
- [#85ztaakuz](https://app.clickup.com/t/85ztaakuz) 
Update code to find RHI on delivery time given by Restaurant and score should be 0 if restaurant is blacklisted

## ⚙️ Deployment Instructions
### Pre deployment steps
- NA

### Post deployment steps
- NA

## Testing Scope QA Instructions
- NA

## Known bugs
- NA

---
# 1.0.2-develop (2023-08-08)

## ✨ New features
- NA

## 🐛 Fixes
- NA

## Improvements
- [#85ztaakuz](https://app.clickup.com/t/85ztaakuz) Store number_of_orders_delivered in restaurant_health_index postgre table
Given weightage to no of transaction in RHI
Store transaction score in restaurant_health_index bigquery table

## ⚙️ Deployment Instructions
### Pre deployment steps
- NA

### Post deployment steps
- NA

## Testing Scope QA Instructions
- NA

## Known bugs
- NA

---
# 1.0.1-develop (2023-06-29)

## ✨ New features
- (https://app.clickup.com/t/85zt6phq7) Restaurant Must_Try, Bestseller Food Recommendation 
  (https://app.clickup.com/t/85ztaakuz) Restaurant Health Index

## 🐛 Fixes
- NA

## Improvements
- NA

## ⚙️ Deployment Instructions
### Pre deployment steps
- NA

### Post deployment steps
- NA

## Testing Scope QA Instructions
- NA

## Known bugs
- NA

---
# 1.0.0-develop

## ✨ New features
- NA

## 🐛 Fixes
- NA

## Improvements
- NA

## ⚙️ Deployment Instructions
- NA

## Special instruction to QA
- NA

## Testing Scope Inclusion/Exclusion
- NA

## Known bugs
- NA