# gintaa-analytics
gintaa-analytics


```commandline
gcloud builds submit --tag=gcr.io/gintaa-cloud-develop/gintaa-analytics/listing_score .

```