import pandas as pd
from config import ConnPath
import psycopg2
import requests


class FraudTransactionProcessor:

    @staticmethod
    def get_blocked_user_list(url, gintaa_api_key):
        headers = {
            "gintaa-api-key": gintaa_api_key
        }

        response = requests.get(url, headers=headers)

        # Check the status code to see if the request was successful (status code 200)
        if response.status_code == 200:
            # Extract the list of 'uid' values
            uid_list = [item['uid'] for item in response.json().get('payload', [])]

            return uid_list
            # print(uid_list)
        else:
            # Print an error message if the request was not successful
            print(f"Error: {response.status_code} - {response.text}")
            return []

    @staticmethod
    def fetch_fraud_write_db():

        url, gintaa_api_key, no_of_days = ConnPath.url_gintaa_api_key_no_of_days()

        # no_of_days = max(1, min(no_of_days, 30))

        blocked_uid_list = FraudTransactionProcessor.get_blocked_user_list(url, gintaa_api_key)
        # return at least 1 value - user id not exists
        blocked_uid_list = blocked_uid_list if len(blocked_uid_list) > 0 else ["1"]

        sql_food_order_connect = ConnPath.food_order_sql_config()
        conn_food_order = psycopg2.connect(database=sql_food_order_connect["database"],
                                           user=sql_food_order_connect["user"],
                                           password=sql_food_order_connect["password"],
                                           host=sql_food_order_connect["host"], port=sql_food_order_connect["port"])
        print("=====ESTABLISHING CONNECTION, DETAILS=====")
        
        # Create a cursor
        cursor = conn_food_order.cursor()

        cursor.execute("TRUNCATE TABLE gintaa_food_order.fraudulent_transactions;")

        sql_query = '''
            WITH trans AS (
                SELECT 
                    id, 
                    uid, 
                    fo.rid, 
                    r.name, 
                    DATE(fo.created_date) created_date
                FROM 
                    gintaa_food_order.food_order fo 
                LEFT JOIN 
                    gintaa_food_order.restaurant r ON r.rid = fo.rid 
                WHERE 
                    fo.created_date >= CURRENT_DATE - INTERVAL '%(no_of_days)s days'  
                    AND gintaa_discount_percent > 0 
                    AND order_status = 'DELIVERED'
                    AND uid not in %(uid_list)s
            ),
            daily_counts AS (
                SELECT
                    uid,
                    rid,
                    created_date,
                    COUNT(*) AS day_count
                FROM trans
                GROUP BY uid, rid, created_date
            ),
            total_counts AS (
                SELECT
                    uid,
                    rid,
                    COUNT(*) AS total_count
                FROM trans
                GROUP BY uid, rid
            ),
            aggregated_daily_counts AS (
                SELECT
                    uid,
                    rid,
                    ARRAY_AGG(json_build_object('date', created_date, 'count', day_count)) AS day_wise_counts
                FROM daily_counts
                GROUP BY uid, rid
            ),
            result_with_reason AS (
                SELECT
                    t.uid,
                    t.rid,
                    MAX(name) AS name,
                    ARRAY_AGG(id) AS order_ids,
                    COALESCE(tc.total_count, 0) AS total_count,
                    CASE
                        WHEN EXISTS (
                            SELECT 1
                            FROM daily_counts dc
                            WHERE dc.day_count >= 3
                                AND dc.uid = t.uid
                                AND dc.rid = t.rid
                        ) THEN 'More than 2 transactions with gintaa discount in a day'
                        WHEN COALESCE(tc.total_count, 0) > 10 THEN 'More than 10 transactions with gintaa discount in a week'
                        ELSE NULL
                    END AS reason
                FROM trans t
                LEFT JOIN total_counts tc USING (uid, rid)
                GROUP BY t.uid, t.rid, tc.total_count
            )
            INSERT INTO gintaa_food_order.fraudulent_transactions (uid, rid, name, order_ids, day_wise_counts, total_count, reason)
            SELECT 
                rr.uid, 
                rr.rid, 
                rr.name, 
                rr.order_ids, 
                adc.day_wise_counts,
                rr.total_count, 
                rr.reason 
            FROM result_with_reason rr
            LEFT JOIN aggregated_daily_counts adc ON rr.uid = adc.uid AND rr.rid = adc.rid
            WHERE reason IS NOT NULL
            ORDER BY uid, rid;
            ''' 
        cursor.execute(sql_query, {'uid_list': tuple(blocked_uid_list), 'no_of_days': no_of_days})

        # Commit the changes
        conn_food_order.commit()

        # Close the cursor and connection
        cursor.close()
        conn_food_order.close()

        return "Table Updated successfully"
